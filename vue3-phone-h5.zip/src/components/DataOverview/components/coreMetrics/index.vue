<template>
    <div class="item">
    </div>
</template>

<script setup>

</script>

<style scoped lang='scss'>
.item {
    width: 351px;
    height: 153px;
    background: #FFFFFF;
    border-radius: 14px 14px 14px 14px;
    opacity: 1;
    position: relative;
    top: -51px;
}
</style>